window.onload = function () {
  console.log(
    "%cHello from your Chrome extension!",
    "color: #fff; background: red; font-size: 20px; padding: 5px;",
  );
};
